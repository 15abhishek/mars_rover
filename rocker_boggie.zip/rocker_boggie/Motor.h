#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

class Motor {
private:
    int pwmPin;
    int dirPin1;
    int dirPin2;

public:
    Motor(int pwm, int d1, int d2);
    void setSpeed(int speed);
    void setFwSpeed(int speed);
    void setBwSpeed(int speed);
    void stop();
};
#endif
