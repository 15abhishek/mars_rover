#include "Motor.h"

Motor::Motor(int pwm, int d1, int d2) {
    pwmPin = pwm;
    dirPin1 = d1;
    dirPin2 = d2;
    pinMode(pwmPin, OUTPUT);
    pinMode(dirPin1, OUTPUT);
    pinMode(dirPin2, OUTPUT);
}

void Motor::setSpeed(int speed) {
    speed = constrain(speed, -255, 255); 
    if (speed > 0) {
        digitalWrite(dirPin1, HIGH);
        digitalWrite(dirPin2, LOW);
        analogWrite(pwmPin, speed);
    } else if (speed < 0) {
        digitalWrite(dirPin1, LOW);
        digitalWrite(dirPin2, HIGH);
        analogWrite(pwmPin, -speed);
    } else {
        digitalWrite(dirPin1, LOW);
        digitalWrite(dirPin2, LOW);
        analogWrite(pwmPin, 0);
    }
}

void Motor::setFwSpeed(int speed){
    digitalWrite(dirPin1, HIGH);
    digitalWrite(dirPin2, LOW);
    analogWrite(pwmPin, abs(speed));   
}

void Motor::setBwSpeed(int speed){
    digitalWrite(dirPin1, LOW);
    digitalWrite(dirPin2, HIGH);
    analogWrite(pwmPin, abs(speed));     
}

void Motor::stop(){
    digitalWrite(dirPin1, LOW);
    digitalWrite(dirPin2, LOW);
    analogWrite(pwmPin, 0); 
}
